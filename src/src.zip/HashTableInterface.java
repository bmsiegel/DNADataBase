
public interface HashTableInterface<T> {

    public long sfold(String s, int M);


    public int getLength();


    public void remove(T remove);


    public void insert(T insert, int index);


    public boolean isOccupied(long hashIndex);


    public DNAEntry get(int index);


    public String toString();

}
